
%%% Harmonic oscillator with forward Euler

%% parameters

t0 = 0.0; % start point
tN = 16.0; % end point
N = 200; % number of intervals
k = 2.0; % spring constant
m = 1.0; % mass
c = 0.0; % damping
x0 = 1.3; % initial displacement
xdot0 = 0.0; % initial velocity

%% derivative

f = @(y,t) [y(2); -k/m*y(1) - c/m*y(2)];

%% time-stepping

t = linspace(t0,tN,N+1); %equispaced points
dt = t(2)-t(1);
y = zeros(2,N+1);
y(:,1) = [x0; xdot0];

for j = 1:N
    y(:,j+1) = y(:,j) + dt*f(y(:,j),t(j));
end

%% total energy over time 

E = 0.5*k*y(1,:).^2 + 0.5*m*y(2,:).^2;
