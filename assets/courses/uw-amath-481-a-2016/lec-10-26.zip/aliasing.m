

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This file demonstrates the aliasing 
% phenomenon for Fourier series
%
% on a grid of size N, the 
% functions exp(i (N/2 + l)x) and 
% exp(i (-N/2 + l)x) look the same
%
% we show them on this coarse grid
% where they appear the same
% and then plot them on a fine grid
% which properly resolves them
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set up equispaced grid on [0,2*pi]

N = 2^3;

x = linspace(0,2*pi,N+1);
xfine = linspace(0,2*pi,1000);
xin = x(1:end-1);

% plot the aliased functions (real and imaginary part)

for i = 1:(N/2-1)
    figure
    str = sprintf('N/2 + %d and -N/2 + %d',i,i);
    
    suptitle(str)
    
    subplot(2,2,1)
    plot(xin,real(exp(1i*(N/2+i)*xin)),'-*g','LineWidth',2)
    hold on
    plot(xfine,real(exp(1i*(N/2+i)*xfine)),'-b','LineWidth',2)
    axis tight
    
    subplot(2,2,2)
    plot(xin,imag(exp(1i*(N/2+i)*xin)),'-*g','LineWidth',2)
    hold on
    plot(xfine,imag(exp(1i*(N/2+i)*xfine)),'-b','LineWidth',2)
    axis tight
    
    subplot(2,2,3)
    plot(xin,real(exp(1i*(-N/2+i)*xin)),'-*g','LineWidth',2)
    hold on
    plot(xfine,real(exp(1i*(-N/2+i)*xfine)),'-b','LineWidth',2)
    axis tight
    
    subplot(2,2,4)
    plot(xin,imag(exp(1i*(-N/2+i)*xin)),'-*g','LineWidth',2)
    hold on
    plot(xfine,imag(exp(1i*(-N/2+i)*xfine)),'-b','LineWidth',2)
    axis tight
    
    
end