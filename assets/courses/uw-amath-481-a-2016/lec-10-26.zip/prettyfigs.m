
set(groot,'defaultAxesColor',[0 0 0])
set(groot,'defaultFigureColor',[0 0 0])
set(groot,'defaultAxesYColor',[1 1 1])
set(groot,'defaultAxesXColor',[1 1 1])
set(groot,'defaultTextColor',[1 1 1])