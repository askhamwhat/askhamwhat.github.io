
%%% compute the derivatives of a function using
%%% fourier series and compare output to 
%%% finite difference approx. of the derivatives

% domain size and number of points

L = 1;
N = 2^10;

% the fft actually computes the sum
% for k = 0, ... N-1
% but due to "aliasing" the values of
% the exponentials for k > N/2 match up
% with exponentials with negative coefficients

kscale = [0:N/2 -N/2+1:-1]*pi/L.';

% the factor that you get when differentiating

kder = 1i*kscale;
kder2 = kder.*kder;
kder3 = kder.*kder2;

% the function of interest

f = @(x) sin(3*pi*x/L) + exp(-30*x.^2);

x = linspace(-L,L,N+1);

xin = x(1:end-1);
fin = f(xin);

figure

plot(xin,fin);

% grab coefficients of f

a = fft(fin);

figure

semilogy(abs(fftshift(a)))

% compute coefficients of f', f'', f''' using the formula

ad1 = kder.*a;
ad2 = kder2.*a;
ad3 = kder3.*a;

% obtain f', f'', f''' using the inverse FFT

find1 = ifft(ad1);
find2 = ifft(ad2);
find3 = ifft(ad3);

% test solution

% get periodic derivative matrix

Ax = uxmatp(L,N);

figure

subplot(1,3,1)
plot(xin,find1,'g','LineWidth',2)
hold on
plot(xin,Ax*(fin'),'--b','LineWidth',2)

subplot(1,3,2)
plot(xin,find2,'g','LineWidth',2)
hold on
plot(xin,Ax*Ax*(fin'),'--b','LineWidth',2)

subplot(1,3,3)
plot(xin,find3,'g','LineWidth',2)
hold on
plot(xin,Ax*Ax*Ax*(fin'),'--b','LineWidth',2)

