
function Ax = uxmatp(L,N)

%% build the matrix for 1d periodic first
%% derivatives with centered differences

% domain [-L,L]

% dimension in x is N

x = linspace(-L,L,N+1);
dx = x(2)-x(1);

% set up the matrix of 1-d centered differences
% for periodic BC's

Ax = spdiags([ones(N,1), -ones(N,1)],[1 -1],N,N);

Ax(1,N) = -1;
Ax(N,1) = 1;

Ax = Ax/(2*dx);