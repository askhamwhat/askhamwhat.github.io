function p = chebpols(x,n)
%
%   simple vectorized chebyshev polynomial evaluator
%   for input in [-1,1]. 
%
%   Returns p(:,...,:,i) = T_i(x)
%   where the number of colons depends on the 
%   dimension of x (if x is a d-tensor, there are 
%   d colons). If x is a column vector, it
%   is treated as a 1-tensor. If x is a row
%   vector, it is treated as a 2-tensor.
%
is = 0:n;
%is = is';

th = acos(x);

dtemp = kron(is,th);

sizex = size(x);

if (length(sizex) == 2)
    if (sizex(2) == 1)
        sizex = [sizex(1)];
    end
end

sizenew = [sizex,n+1];

dtemp = reshape(dtemp,sizenew);

p = cos(dtemp);

end