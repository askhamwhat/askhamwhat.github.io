
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% code used for examples 
% in chapter 4 of ATAP
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Plot showing aliasing

n = 4;

% get chebyshev polynomials

for i = 1:2*n+1
    T{i} = chebpoly(i-1);
end

% get chebyshev points

xx = chebpts(n+1);

% plot functions and what they
% look like on coarse grid

figure
for i = 1:n
    subplot(n,2,2*(i-1)+1)
    plot(T{i})
    hold on
    plot(xx,T{i}(xx),'-x')
    ylim([-1 1])
    subplot(n,2,2*i)
    plot(T{2*n-(i-2)})
    hold on
    plot(xx,T{2*n-(i-2)}(xx),'-x')
    ylim([-1 1])
end

%% compare projection (truncated chebyshev series)
%% with interpolant, for a low-ish degree

x = chebfun('x');
f = tanh(4*x-1);

n = 4;

% get projection onto nth degree

figure
plot(f,'b')
hold on
fn = chebfun(f,'trunc',n+1); plot(fn,'-.g')
pn = chebfun(f,n+1); plot(pn,'--.r')

% compare error 

figure 
subplot(1,2,1); plot(f-fn,'g')
subplot(1,2,2); plot(f-pn,'r')

%% compare projection (truncated chebyshev series)
%% with interpolant, for a higher degree

x = chebfun('x');
f = tanh(4*x-1);

n = 24;

% get projection onto nth degree

figure
plot(f,'b')
hold on
fn = chebfun(f,'trunc',n+1); plot(fn,'-.g')
pn = chebfun(f,n+1); plot(pn,'--.r')

% compare error 

figure 
subplot(1,2,1); plot(f-fn,'g')
subplot(1,2,2); plot(f-pn,'r')


