
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Heat equation example in 2D (periodic)
%
% Forward Euler version
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% parameters

L = 1; % solve on grid [-L,L] x [-L,L]
N = 100; % number of spatial grid points
N2 = N^2; % total number of grid points
t0 = 0; % start time
T = 1; % end time
kappa = 0.125; % thermal diffusivity

% number of time points
NT = ceil(kappa*N); % scale with grid points
NT = N;
NT = ceil(kappa*N^2); % scale with square of grid points
                      % only one of these is stable
dt = (T-t0)/NT;

%% initial condition u_0 = f(x)
f = @(x,y) sin(3*pi*x/L)+2 + cos(3*pi*y/L);

%% set up grid
x = linspace(-L,L,N+1);
x = x(1:end-1); % cut-off last point due to periodicity
dx = x(2)-x(1);
y = x;

[xx,yy] = meshgrid(x,y);

%% initialize
u0 = reshape(f(xx,yy),N2,1);

u0grid = reshape(u0,N,N);

surf(xx,yy,u0grid,'EdgeColor','none')

%% get finite difference matrix
A = lapumatp2d(N)*kappa/(dx^2);

%% solve with Forward Euler (u^n+1  = u^n + dt*A*u^n)

tic
u = u0;
for i = 1:NT
    u = u+dt*A*u;
end
toc

%% plot result

ugrid = reshape(u,N,N);
surf(xx,yy,ugrid,'EdgeColor','none')
