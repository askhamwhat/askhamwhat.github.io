
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Heat equation example in 1D (periodic)
%
% Forward Euler version
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% parameters

L = 1; % solve on grid [-L,L]
N = 100; % number of spatial grid points
t0 = 0; % start time
T = 1; % end time
kappa = 0.125; % thermal diffusivity

% number of time points
NT = ceil(kappa*N); % scale with grid points
NT = N;
NT = ceil(kappa*N^2); % scale with square of grid points
                      % only one of these is stable
dt = (T-t0)/NT;

%% initial condition u_0 = f(x)
f = @(x) sin(3*pi*x/L)+2;

%% set up grid
x = linspace(-L,L,N+1);
x = x(1:end-1); % cut-off last point due to periodicity
dx = x(2)-x(1);

%% initialize
u0 = f(x)';

%% get finite difference matrix
A = uxxmatp(N)*kappa/(dx^2);

%% solve with Forward Euler (u^n+1  = u^n + dt*A*u^n)

u = u0;
for i = 1:NT
    u = u+dt*A*u;
end

%% plot result

plot(x,u)