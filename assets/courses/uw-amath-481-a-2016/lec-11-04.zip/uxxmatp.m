
function A = uxxmatp(n)

%%%% build the 2nd order centered finite difference matrix (of size nxn)
%%%% approximation to the second derivative on a uniform grid
%%%% (assuming a periodic domain), in sparse format.

%%%% to get true matrix, scale by 1/dx^2, where dx
%%%% is the grid spacing

%% 1d periodic boundary conditions ...

A = -2*speye(n) + spdiags(ones(n,2),[1 -1],n,n);
A(1,n) = 1;
A(n,1) = 1;