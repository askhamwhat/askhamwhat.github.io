
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This is an implementation of program 37
% from spectral methods in matlab (using 
% some chebfun features)
%
% Wave equation in a "wave tank"
%
% u_tt = u_xx + u_yy
%
% periodic in x direction
%
% neumann boundary conditions in y direction
% (these are like free moving boundary conditions
% or allowing the waves to splash up the 
% sides of the tank)
%
% We'll use equispaced points and Fourier series
% for the x direction and Chebyshev points for y
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set up grid

N = 60;
M = 60;
L = pi;
N = 100;
M = 500;
L = 10;
y = chebpts(N+1);
x = linspace(-L,L,M+1);
x = x(1:end-1);
[xx,yy] = meshgrid(x,y);

% chebyshev differentiation operator (for y direction)

d2op = chebop(@(u) diff(u,2));
D2N = d2op(N+1);
dop = chebop(@(u) diff(u));
DN = dop(N+1);

% Neumann bc's system for y direction

BC = -DN([1 end],[1 end])\DN([1 end],2:end-1);

% time stepping

t0 = 0;
tmax = 8;
tmax = 20;

nframes = 120;
tplot = (tmax-t0)/nframes;
dt = 5/(M+N^2);
plotgap = round(tplot/dt);
dt = tplot/plotgap;
nplots = round(tmax/tplot);

% intial condition for ridge traveling to the right)

vv = exp(-8*((xx+1.5).^2));
vvold = exp(-8*((xx+1.5+dt).^2));

% initial condition
% note: this corresponds to a strange initial condition
% u(x,0) = gaussian bump, u_t(x,0) = u_x(x,0)

if (1 == 1)
    vv = exp(-8*((xx+1.5).^2 + yy.^2));
    vvold = exp(-8*((xx+1.5+dt).^2 + yy.^2));
end

if (1 == 0)
    vv = exp(-8*((xx+1.5).^2 + yy.^2));
    vvold = exp(-8*((xx+1.5).^2 + (yy+dt).^2));
end


surf(xx,yy,vv,'EdgeColor','none')

% storage for plots

plotdata = zeros(size(vv,1),size(vv,2),nplots+1);
plotdata(:,:,1) = vv;
tdata = zeros(nplots+1,1);
tdata(1) = t0;
%clf, drawnow, h = waitbar(0,'please wait ...')

% do time stepping (Leap frog)

for i = 1:nplots, waitbar(i/nplots)
    for n = 1:plotgap
        dxxv = dx2_fft(vv,2,L);
        dyyv = D2N*vv;
        
        % Leap frog
        
        vvnew = 2*vv - vvold + dt^2*(dxxv+dyyv);
        
        % enforce boundary conditions
        
        vvnew([1 end],:) = BC*vvnew(2:end-1,:);
        
        vvnew = real(vvnew);
        
        % update storage
        
        vvold = vv;
        vv = vvnew;
        
    end
    plotdata(:,:,i+1) = vv;
    tdata(i+1) = t0 + dt*i*plotgap;
end

%% movie section

datamin = min(min(min(plotdata)));
datamax = max(max(max(plotdata)));
xmin = min(x);
xmax = max(x);
ymin = min(y);
ymax = max(y);

mframes(nplots+1) = struct('cdata',[],'colormap',[]);

for i = 1:nplots+1
    surf(xx,yy,plotdata(:,:,i),'EdgeColor','none')
    axis([-L L -1 1 -1 1])
    view(-10,60)
    title(round(10*tdata(i))/10)
    mframes(i) = getframe;
end

lm = 10;
fps = round((nplots+1)/lm);
movie(mframes,1,fps)
