
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This is an implementation of program 19
% from spectral methods in matlab (using 
% some chebfun features)
%
% Solve 2nd-order (two-way) wave equation
% with Chebyshev collocation
%
% Dirichlet (fixed end) boundary conditions
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = 200;
x = chebpts(N+1);
d2op = chebop(@(u) diff(u,2));
D2N = d2op(N+1);

lambda = 8;
dt = lambda/(N+1)^2;

% second order in time, need two initial conditions
% for leap frog

% one wave going left

v = exp(-200*x.^2); 
vold = exp(-200*(x-dt).^2);

% waves going in two directions

v = exp(-200*(x-0.5).^2) + 0.5*exp(-200*(x+0.5).^2); 
vold = exp(-200*(x-0.5+dt).^2) + 0.5*exp(-200*(x+0.5-dt).^2);


% start and end times

t0 = 0;
tmax = 4;

% set up grabbing frames in time

nframes = 120;
tplot = (tmax-t0)/nframes;
plotgap = round(tplot/dt);
dt = tplot/plotgap;
nplots = round(tmax/tplot);

% storage for plots

plotdata = [v'; zeros(nplots,N+1)];
tdata = zeros(nplots+1,1);
tdata(1) = t0;
clf, drawnow, h = waitbar(0,'please wait ...')

% do time stepping 

for i = 1:nplots, waitbar(i/nplots)
    for n = 1:plotgap
        dv = D2N*v;
        
        % leap frog for (d/dt)^2
        
        vnew = 2*v - vold + dt^2*dv;
        
        % enforce boundary conditions
        
        vnew(1) = 0;
        vnew(end) = 0;
        
        % update storage
        
        vold = v;
        v = vnew;
    end
    plotdata(i+1,:) = v;
    tdata(i+1) = t0 + dt*i*plotgap;
end

%% plotting section

% plot results
clf, drawnow, waterfall(x,tdata,plotdata)

%% movie section

lm = 6.0;
datamin = min(min(plotdata));
datamax = max(max(plotdata));
xmin = min(x);
xmax = max(x);

for i = 1:nplots+1
    plot(x,plotdata(i,:))
    xlim([xmin xmax])
    ylim([datamin datamax])
    pause(lm/nplots)
end
