
function dxf = dxf_fft(f,DIM,L)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Input:
%  f - matrix of function values
%  DIM - dimension along which to do
%        differentiation
%  L - half-length of domain
%
% Output:
%
% dxf - derivative of f using 
% spectral Fourier differentiation
% for each column or row along the 
% requested dimension
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch nargin
    case 0
        error('No input data');
        return
    case 1
        DIM = 1;
        L = pi;
    case 2
        L = pi;
end

if (DIM ~= 2 && DIM ~= 1)
    error('DIM must be 1 or 2')
    return
end

sizef = size(f);
if (length(sizef) > 2)
    error('only matrix or vector input allowed')
end
nfft = sizef(DIM);
nother = sizef(mod(DIM,2)+1);

kscalex = 1i*[0:nfft/2 -((nfft+mod(nfft,2))/2)+1:-1]*pi/L.';
scaleother = ones(nother,1);

if (DIM == 1)
    [dumb,scale] = meshgrid(scaleother,kscalex);       
else
    [scale,dumb] = meshgrid(kscalex,scaleother);
end

fhat = fft(f,[],DIM);
dxfhat = scale.*fhat;
dxf = ifft(dxfhat,[],DIM);