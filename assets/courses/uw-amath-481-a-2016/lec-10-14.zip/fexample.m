function F = fexample(u)

%% parameters

t0 = 0;
tN = 1;
u0 = 4;
uN = 1;

%% figure out size from input

Nm1 = length(u);
N = Nm1 + 1;

dt = (tN-t0)/N;

% finite difference approximation
% of the equation u'' - u^2

F = zeros(size(u));

F(1) = (u(2)-2*u(1)+u0)/(dt^2)-u(1)^2;

for i = 2:N-2
    F(i) = (u(i+1)-2*u(i)+u(i-1))/(dt^2)-u(i)^2;
end

F(N-1) = (uN-2*u(N-1)+u(N-2))/(dt^2)-u(N-1)^2;