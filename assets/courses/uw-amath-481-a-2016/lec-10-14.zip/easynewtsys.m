function [x0,niter,errs,x0save] = easynewtsys(f,J,xstart,nmax,tol)
%%%%%%%%%%%%%%
% Simple implementation of Newton's method
%%%%%%%%%%%%%%

errs = [];
x0 = xstart;
niter = 0;

if (norm(f(x0)) < tol)
    return;
end

errs = zeros(nmax,1);
x0save= zeros(length(x0),nmax);

for i = 1:nmax
    niter = i;
    x0 = x0 - J(x0)\f(x0);
    x0save(:,i) = x0;
    errs(i) = norm(f(x0));
    if (errs(i) < tol)
        break;
    end
end

errs = errs(1:niter);
x0save = x0save(:,1:niter);