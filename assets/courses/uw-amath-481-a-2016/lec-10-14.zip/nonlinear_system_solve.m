
%%%%%%%%%%%%%%%%%%%%%%%%
% We will use MatLab's built in
% nonlinear solver and centered
% finite differences to solve
% the equation u''=u^2, u(0) = 4, u(1) = 1
%%%%%%%%%%%%%%%%%%%%%%%%

% much of the problem is defined in
% fexample.m

% parameter

N = 200;
x = linspace(0,1,N+1);
xin = x(2:end-1);

% initial guess

u0 = 4-3*xin';

% call nonlinear solver
% and time it

% note: you may not have the 
% optimization toolbox, which
% includes FSOLVE

nmax = 100;
tol = 1.0e-9;

tic;
%usol = fsolve(@fexample,u0);
[usol,niter,errs,x0save] = easynewtsys(@fexample,@dfexample,u0,nmax,tol);
time = toc;

display(niter)
display(time)

figure
plot(xin,usol)
hold on
plot(xin,x0save(:,1))
plot(xin,x0save(:,2))
plot(xin,x0save(:,3))


% check if it is a solution of the 
% system of equations

norm(fexample(usol))/sqrt(N)