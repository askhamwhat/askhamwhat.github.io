function err = fshoot(s,pars)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

f = pars{1};
g = pars{2};
x = pars{3};
u0 = pars{4};
uNgoal = pars{5};

% solve ode with this guess for 
% starting velocity

udot0 = s;

y0 = [u0; udot0];

[xout,yout] = ode45(g,x,y0);
        
uNout = yout(end,1);

err = uNout-uNgoal;
        