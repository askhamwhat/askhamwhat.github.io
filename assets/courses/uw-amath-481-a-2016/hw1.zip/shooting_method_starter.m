%%% Shooting method

%% This file uses the shooting method to
%% solve the BVP below. Modify to solve the
%% problem for the homework.

%% -u'' = f, u(0) = u0, u(1) = u1

%% parameters for BVP

x0 = 0.0; % start point
xN = 1.0; % end point
N = 1000; % number of intervals

fdelta = 0.0001; %smaller fdelta = narrower f (goes to delta mass)

u0 = 0.0d0; %initial displacement
uN = 0.0d0; %goal displacement at x_N

%% derivative

f = @(x) exp(-(x-0.5).^2/fdelta)/sqrt(fdelta);
g = @(x,y) [y(2); -f(x)];

%% time-stepping

x = linspace(x0,xN,N+1); %equispaced points

%% check out density f

figure
plot(x,f(x))

%% set-up parameters for fshoot

pars{1} = f;
pars{2} = g;
pars{3} = x;
pars{4} = u0;
pars{5} = uN;

%% check out structure of shooting
%% problem

svals = linspace(-1,5);
fshootvals = zeros(size(svals));

for i = 1:length(svals)
    fshootvals(i) = fshoot(svals(i),pars);
end

figure
plot(svals, fshootvals)

udot_l = -1;
udot_r = 1;

%% parameters for bisection 

nmax = 100;
tol = 1.0e-4; % desired tolerance

[s0,niter,ier,ansv,bnsv] = bisection(udot_l,udot_r,@fshoot,pars,tol,nmax);

% did we succeed?

ier

%% compute solution using this inital velocity

udot0 = s0;

y0 = [u0; udot0];
[xout,yout] = ode45(g,x,y0);

figure
plot(xout,yout)

