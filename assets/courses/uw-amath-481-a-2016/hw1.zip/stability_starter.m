
%%% stability regions

%% this code plots stability regions
%% for one step methods
%% modify this code to plot the stability
%% region for the Adams Bashforth method
%% in the homework

%% Note: changing to Adams Bashforth is a 
%% bit tricky... need BOTH roots to be good.

%f = @(z) 1 + z; % Forward Euler
f = @(z) 1 + z + z.^2/2.0; % Heun's
%f = @(z) 1 + z + z.^2/2.0 + z.^3/6.0 + z.^4/24.0; %RK4
f = @(z) 1./(1-z); % backward Euler
f = @(z) (1+z)./(1-z); % trapezoidal rule

g = @(z) abs(f(z));

x = linspace(-5,5,200);
y = linspace(-5,5,200);

[X,Y] = meshgrid(x,y);
Z = X+1i*Y;

G = g(Z);

figure

contourf(X,Y,G,[1.0 1.0])
axis equal

x_yax = zeros(size(y));
y_xax = zeros(size(x));

hold on
plot(x_yax,y)
plot(x,y_xax)




