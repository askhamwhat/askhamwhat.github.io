%% simple function

f = @(x,pars) (x-1).^3 - x.^2 + 2;
pars = {};

a0 = 1;
b0 = 2;

x = linspace(a0,b0);

figure
plot(x,f(x))
hold on
plot(x,zeros(size(x)))

%% compute zero using bisection

tol = 1.0e-9;
nmax = 53;

[x0,niter,ier,ansv,bnsv] = bisection(a0,b0,f,pars,tol,nmax);

x0
niter
ier


plot(x0,f(x0),'ro')