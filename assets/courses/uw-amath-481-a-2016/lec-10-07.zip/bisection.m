function [x0,niter,ier,ansv,bnsv] = bisection(a0,b0,f,pars,tol,nmax)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Basic bisection code
%
% Input:
%
%   a0, b0: initial interval (containing zero) is [a0,b0]
%   f: anonymous function handle of the form f(x,pars)
%   pars: array of parameters passed to function f, as above
%   tol: desired tolerance
%   nmax: maximum number of bisections to attempt
%
% Output:
%
%   x0: location of a zero (if successful), i.e. |f(x0)| < tol
%   ier: 0 if successful, 1 if didn't converge, 2 if bad [a0,b0]
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

an = a0;
bn = b0;
ier = 1;
x0 = (an+bn)/2;
ansv = zeros(nmax,1);
bnsv = zeros(nmax,1);
niter = 0;

fa = f(a0,pars);
fb = f(b0,pars);

% check if a0 or b0 are solutions

if ( abs(fa) < tol )
    ier = 0;
    niter = 0;
    x0 = a0;
    return;
end

if ( abs(fb) < tol )
    ier = 0;
    niter = 0;
    x0 = b0;
    return;
end

% check that fa and fb are opposite signs

if (fa*fb > 0)
    ier = 2;
    return
end

% check which is positive, left or right end

if (fb > 0)
    sign = 1;
else
    sign = -1;
end

ansv = zeros(nmax,1);
bnsv = zeros(nmax,1);

% perform bisection

for i = 1:nmax
    niter = i;
    x0 = (an+bn)/2;
    fval = f(x0,pars);
    ansv(i) = an;
    bnsv(i) = bn;
    if (abs(fval) < tol)
        ier = 0;
        break
    end
    if (sign*fval > 0)
        bn = x0;
    else
        an = x0;
    end
end

ansv = ansv(1:niter);
bnsv = bnsv(1:niter);