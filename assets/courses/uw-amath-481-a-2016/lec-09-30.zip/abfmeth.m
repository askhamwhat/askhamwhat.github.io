function y = abfmeth(f,t,y0,y1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Adams Bashforth method (order 2)
%
% f - function handle f(y,t)
% t - solution times (must be equispaced)
% y0 - initial value
% y1 - second initial value
%
% OUTPUT
%
% y - solution of ODE using Adams
% Bashforth (order 2) method
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ASSUMES EQUISPACED

y(:,1) = y0;
y(:,2) = y1;

fim2 = f(y0,t(1));
fim1 = f(y1,t(2));

for i = 3:length(t)
    dt = t(i)-t(i-1);
    y(:,i) = y(:,i-1) + 0.5*dt*(3.0*fim1-fim2);
    fim2 = fim1;
    
    % 1 function eval
    
    fim1 = f(y(:,i),t(i));
end
