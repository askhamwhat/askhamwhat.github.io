
%%% Harmonic oscillator with forward Euler

%% parameters

t0 = 0.0; % start point
tN = 16.0; % end point
N = 100; % number of intervals
Nexact = 2000; % "exact" solution
k = 2.0; % spring constant
m = 1.0; % mass
c = 0.0; % damping
x0 = 1.3; % initial displacement
xdot0 = 0.0; % initial velocity

%% derivative

f = @(y,t) [y(2); -k/m*y(1) - c/m*y(2)];

%% time-stepping

t = linspace(t0,tN,N+1); %equispaced points
dt = t(2)-t(1);
texact = linspace(t0,tN,Nexact+1);
yfe = zeros(2,N+1);
yrk4 = zeros(2,N+1);
yabf = zeros(2,N+1);
yexact = zeros(2,Nexact+1);
y0 = [ x0; xdot0];
y1 = y0 + dt*f(y0,t0);

%% apply time stepping scheme

yfe = femeth(f,t,y0);
yrk4 = rk4meth(f,t,y0);
yabf = abfmeth(f,t,y0,y1);
% 'exact' solution on fine grid
yexact = rk4meth(f,texact,y0);

%% plot solution

hold off
plot(texact,yexact(1,:),'b','LineWidth',2)
hold on
plot(t,yfe(1,:),'g','LineWidth',2)
plot(t,yrk4(1,:),'r','LineWidth',2)
plot(t,yabf(1,:),'m','LineWidth',2)
