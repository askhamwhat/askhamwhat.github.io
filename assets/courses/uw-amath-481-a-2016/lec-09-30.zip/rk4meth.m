function y = rk4meth(f,t,y0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Runge Kutta (order 4) method
%
% f - function handle f(y,t)
% t - solution times
% y0 - initial value
%
% OUTPUT
%
% y - solution of ODE using the
% classic 4th order RK method
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

y(:,1) = y0;

for i = 2:length(t)
    dt = t(i)-t(i-1);
    
    % 4 function evals
    
    f1 = f(y(:,i-1),t(i-1));
    f2 = f(y(:,i-1)+0.5*dt*f1,t(i-1)+0.5*dt);
    f3 = f(y(:,i-1)+0.5*dt*f2,t(i-1)+0.5*dt);
    f4 = f(y(:,i-1)+dt*f3,t(i-1)+dt);
    y(:,i) = y(:,i-1) + dt*(f1+2.0*f2+2.0*f3+f4)/6.0;
end
