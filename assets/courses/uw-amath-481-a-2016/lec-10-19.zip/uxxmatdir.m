
function A = uxxmatdir(n)

%%%% build the 2nd order centered finite difference matrix
%%%% of size nxn, in sparse format.

%% 1d Dirichlet boundary conditions ...

A = -2*speye(n) + spdiags(ones(n,2),[1 -1],n,n);