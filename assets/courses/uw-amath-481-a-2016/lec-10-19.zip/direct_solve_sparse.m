

%% get 1d finite difference matrix

% compare sparse and full formats

A5 = uxxmatdir(5);
A5
full(A5)

[l,u,p] = lu(A5)
[l,u,p] = lu(full(A5))

% tridiagonal, very sparse

A100 = uxxmatdir(100);
spy(A100)
[l,u] = lu(A100)
spy(l)
spy(u)

% see how storage, flop count scales in 1D

ntimes = 6;
times = zeros(ntimes,1);
nmats = zeros(ntimes,1);
nnzs = zeros(ntimes,1);

for n = 1:ntimes
    nmat = 10^n;
    A = uxxmatdir(nmat);
    tic;
    [l,u] = lu(A);
    times(n) = toc;
    nmats(n) = nmat;
    nnzs(n) = nnz(l)+nnz(u);
end

figure

loglog(nmats,nmats,'-') % linear trend
hold on
loglog(nmats,1e-6*nmats,'-') % linear trend
loglog(nmats,nnzs,'o') % storage
loglog(nmats,times,'x') % computational time

%% get 2d finite difference matrix

% compare sparse and full formats

% size 16 = 4^2

A4 = lapumatdir2d(4);
A4
full(A4)

[l,u] = lu(A4)
[l,u] = lu(full(A4))

% very sparse, off diagonals are sqrt(n) away..

A40 = lapumatdir2d(40);
hold off
spy(A40)

% l and u factors have "fill-in"
% ~ n^3/2 non zero entries

[l,u] = lu(A40);
spy(l)
spy(u)

% see how storage, flop count scales in 2D

ntimes = 6;
times = zeros(ntimes,1);
nmats = zeros(ntimes,1);
nnzs = zeros(ntimes,1);

for n = 1:ntimes
    nmat1 = 2^n;
    nmat2 = nmat1^2;
    A = lapumatdir2d(nmat1);
    tic;
    [l,u] = lu(A);
    times(n) = toc;
    nmats(n) = nmat2;
    nnzs(n) = nnz(l)+nnz(u);
end

figure

loglog(nmats,nmats,'-') % linear trend
hold on
loglog(nmats,nmats.^1.5,'--') % N^3/2 trend
loglog(nmats,1e-6*nmats,'-') % linear trend
loglog(nmats,1e-7*nmats.^1.5,'--') % N^3/2 trend
loglog(nmats,nnzs,'o') % storage
loglog(nmats,times,'x') % computational time

%% in 2d you need more points and its slower per point! (even worse in 3d)

