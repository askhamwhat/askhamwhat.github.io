
%%%% timings for dense LU and Gaussian elimination

nn = 12;

ns = zeros(nn,1);
timeformLU = zeros(nn,1);
timesolveLU = zeros(nn,1);
timesolveldiv = zeros(nn,1);

for iii = 1:nn

    n = 2^iii;
    
    ns(iii) = n;
    
    m = n+10;

    A = rand(n,m)*rand(m,n);

    b = rand(n,1);


    ntiming = 10;
    
    if (n > 1000) 
        ntiming = 2;
    end

    % time forming LU

    tic;
    for i = 1:ntiming
        [l,u,p] = lu(A,'vector');
    end

    timeformLU(iii) = toc/ntiming;

    % time solving LU

    tic;
    for i = 1:ntiming
        x = u\(l\b(p));
    end

    timesolveLU(iii) = toc/ntiming;

    % time solving \

    tic;
    for i = 1:ntiming
        x = A\b;
    end

    timesolveldiv(iii) = toc/ntiming;
end

figure
loglog(ns,1e-10*ns.^3,'-')
hold on
loglog(ns,1e-9*ns.^2,'--')
loglog(ns,timeformLU,'x')
loglog(ns,timesolveLU,'o')
loglog(ns,timesolveldiv,'+')

%% LU solve scales as N^2 instead of N^3. If you need to perform
%% multiple solves for some matrix, compute LU and then solve the 
%% rest with LU backward/forward substitution.
