
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This is an implementation of program 35
% from spectral methods in matlab (using 
% some chebfun features)
%
% Solve Allen-Cahn equation
%
% u_t = u_xx + u - u^3
%
% Dirichlet boundary conditions
%
% u(-1) = -1, u(1) = 1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = 60;
x = chebpts(N+1);
d2op = chebop(@(u) diff(u,2));
D2N = d2op(N+1);

eps = .01; % diffusion parameter

dt = min( [.01, 10*N^(-4)/eps ]); % stiff equation
ifreaction = 1; % = 1 means reaction diffusion, = 0 just diffusion

% start and end times

t0 = 0;
tmax = 40;

% initial condition (sections near each stable state)

v = .53*x + .47*sin(-1.5*pi*x); % use tmax = 40
vleft = -1;
vright = 1;

if (1 == 1) % use tmax = 60 and try ifreaction = 0 and 1
    ifreaction = 1;
    v = -1-2*exp(-10) + 2*exp(-10*x.^2);
    vleft = -1;
    vright = -1;
    tmax = 60;
end
plot(v)



% set up grabbing frames in time

nframes = 120;
tplot = (tmax-t0)/nframes;
plotgap = round(tplot/dt);
dt = tplot/plotgap;
nplots = round(tmax/tplot);

% storage for plots

plotdata = [v'; zeros(nplots,N+1)];
tdata = zeros(nplots+1,1);
tdata(1) = t0;
%clf, drawnow, h = waitbar(0,'please wait ...')

% do time stepping (Forward euler)

for i = 1:nplots, waitbar(i/nplots)
    for n = 1:plotgap
        dv = D2N*v;
        
        % forward Euler
        
        vnew = v + dt*(eps*dv+ifreaction*(v-v.^3));
        
        % enforce boundary conditions
        
        vnew(1) = vleft;
        vnew(end) = vright;
        
        % update storage
        
        v = vnew;
    end
    plotdata(i+1,:) = v;
    tdata(i+1) = t0 + dt*i*plotgap;
end

%% plotting section

% plot results
clf, drawnow, waterfall(x,tdata,plotdata)

%% movie section

lm = 10.0;
datamin = min(min(plotdata));
datamax = max(max(plotdata));
xmin = min(x);
xmax = max(x);

for i = 1:nplots+1
    plot(x,plotdata(i,:))
    xlim([xmin xmax])
    ylim([datamin datamax])
    title(round(10*tdata(i))/10)
    pause(lm/nplots)
end
