function A = fdmatuxx(N,t0,tN)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This function returns the matrix
% A corresponding to the centered
% differences approximation of u_xx
% with the Dirichlet boundary condition
% (i.e. the function values are specified
% on the boundary) on the interval
% [t0,tN] using N intervals to discretize
% (which gives N-1 interior
% unknowns)
%     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
dt = (tN-t0)/N;

A = zeros(N-1);

A(1,1) = -2;
A(2,1) = 1;

% running through columns
% is better than rows for
% efficient memory access

for i = 2:N-2
    A(i-1,i) = 1;
    A(i,i) = -2;
    A(i+1,i) = 1;
end

A(N-2,N-1) = 1;
A(N-1,N-1) = -2;

A = A/(dt^2);
