function [x0,niter,errs,x0save] = easynewt(f,df,xstart,nmax,tol)
%%%%%%%%%%%%%%
% Simple implementation of Newton's method
%%%%%%%%%%%%%%

errs = [];
x0 = xstart;
niter = 0;

if (abs(f(x0)) < tol)
    return;
end

errs = zeros(nmax,1);
x0save= zeros(nmax,1);

for i = 1:nmax
    niter = i;
    x0 = x0 - f(x0)/df(x0);
    x0save(i) = x0;
    errs(i) = abs(f(x0));
    if (errs(i) < tol)
        break;
    end
end

errs = errs(1:niter);
x0save = x0save(1:niter);