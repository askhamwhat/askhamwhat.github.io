
%%% try Newton's method on a bad function

% solve f(x)=0

% no derivative at root
f1 = @(x) sign(x).*abs(x).^(1/3);
df1 = @(x) x.^(-2/3)/3.0;
x0exact1 = 0;
% double root
f2 = @(x) x.^(2);
df2 = @(x) 2*x;
x0exact2 = 0;
% nearly double root
f3 = @(x) x.^2 - 1e-8;
df3 = @(x) 2*x;
x0exact3 = sqrt(1e-8);

f = f2;
df = df2;
x0exact = x0exact2;

x = linspace(-2,2);

fx = f(x);

figure
plot(x,fx)

xstart = 0.75;
nmax = 100;
tol = 1.0e-12;

[x0,niter,errs,x0save] = easynewt(f,df,xstart,nmax,tol);

hold on
%scatter(x0save,(f(x0save)))

figure
semilogy(errs)

errsx = abs(x0save-x0exact);

figure
semilogy(errsx)

