%% -u'' = f, u(0) = u0, u(1) = u1

%% parameters for BVP

x0 = 0.0; % start point
xN = 1.0; % end point
N = 1000; % number of intervals

fdelta = 0.0001; %smaller fdelta = narrower f (goes to delta mass)

u0 = 0.0d0; %initial displacement
uN = 0.0d0; %goal displacement at x_N

%% derivative

f = @(x) exp(-(x-0.5).^2/fdelta)/sqrt(fdelta);

%% discretization

x = linspace(x0,xN,N+1); %equispaced points
dx = x(2)-x(1);

%% check out density f

figure
plot(x,f(x))

%% set up linear system and solve

xin = x(2:end-1);
fin = f(xin);

bin = fin';
bin(1) = bin(1) - u0/dx^2;
bin(end) = bin(end) - uN/dx^2;

A = -fdmatuxx(N,x0,xN);

% call MatLab's built in linear solver

uin = A\bin;

% plot results

figure
plot(xin,uin)

