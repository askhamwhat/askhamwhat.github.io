function J = dfexample(u)

%% parameters

% Jacobian corresponding to fexample

t0 = 0;
tN = 1;
u0 = 4;
uN = 1;

%% figure out size from input

Nm1 = length(u);
N = Nm1 + 1;

dt = (tN-t0)/N;

% finite difference approximation
% of the equation u'' - u^2

J = zeros(Nm1,Nm1);

J(1,1) = -2/dt^2-2*u(1);
J(2,1) = 1/dt^2;

for i = 2:N-2
    J(i-1,i) = 1/dt^2;
    J(i,i) = -2/dt^2-2*u(i);
    J(i+1,i) = 1/dt^2;
end

J(N-2,N-1) = 1/dt^2;
J(N-1,N-1) = -2/dt^2-2*u(N-1);