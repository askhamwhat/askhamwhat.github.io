
%%% try Newton's method on an easy function

% solve f(x)=0

f = @(x) (x-1).^5 - 2* x.^2 + 3;
df = @(x) 5*(x-1).^4 - 4*x;
% why 5th order polynomial?


x = linspace(0,2);

fx = f(x);

figure
plot(x,fx)

xstart = 0.75;
nmax = 100;
tol = 1.0e-12;

[x0,niter,errs,x0save] = easynewt(f,df,xstart,nmax,tol);

semilogy(errs)

