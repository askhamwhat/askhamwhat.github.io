
%%%%%%%%%%%%%%%%%%%%%%%%
%
% Code for examples from
% Chapter 21 of ATAP
%
%%%%%%%%%%%%%%%%%%%%%%%%

%% differentiation

x = chebfun('x');
p = sin(x);
length(p)

pp = diff(p); 
x14 = chebpts(14);
pp14 = pp(x14)

D = chebop(@(u) diff(u));
D14 = D(14);
norm(D14*p(x14)-pp14)
norm(D14*p(x14)-cos(x14))

%% 

D(3)

D(5)

%% second derivative

D2 = chebop(@(u) diff(u,2));
D2(5)

norm(D2(5)-(D(5))^2)

%% formula for derivatives

p3 = chebfun([0; 0; 0; 1; 0]);
plot(p3,'.-')

p3pp = diff(p3,2);
x5 = chebpts(5);
p3pp(x5)

D25 = D2(5);

D25(:,4)

%% differential operator for 
%% u'' + u' + 100u = x, u(0) = 0, u(1) = 0

L = chebop( @(u) diff(u,2) + diff(u) + 100*u);
L(5)

%% add boundary conditions

L.bc = 'dirichlet';
feval(L,5,'oldschool')

%% with small number of points

x5 = chebpts(5); 
x5([1 end]) = 0;
A5 = feval(L,5,'oldschool');
u5 = A5\x5;
plot(chebfun(u5),'.-')

%% with more points

x12 = chebpts(12); 
x12([1 end]) = 0;
A12 = feval(L,12,'oldschool');
u12 = A12\x12;
plot(chebfun(u12),'.-')

%% let chebfun choose number of points
%% adaptively

x = chebfun('x');
u = L\x;
plot(u,'.-')
length(u)
norm(L*u-x)

%% other types of BCs 

L.bc = 'neumann';
feval(L,5,'oldschool')

%% solve again (letting chebfun
%% choose number of points

u = L\x;
plot(u,'.-')

%% variable coefficient problem
%% Airy equation u'' - xu = 0
%% bvp u(-30) = 1, u(30) = 0

L = chebop( @(x,u) diff(u,2) - x.*u,[-30,30]);
L.lbc = 1;
L.rbc = 0;

u = L\0;

% plot solution, note how it changes from
% oscillatory to exponential at
% x = 0

plot(u)

%% nonlinear problem
%% theta '' + sin(theta) = 0

tl = 0;
tr = 6;

N = chebop( @(theta) diff(theta,2) + sin(theta),[tl, tr]);
N.lbc = -pi/2;
N.rbc = pi/2;

% can still call backslash to solve
% but chebfun is doing a lot under the
% hood here. In particular, chebfun
% is setting up and solving a newton 
% iteration

tic; theta = N\0; toc

% plot the height
plot(-cos(theta))

%% different solution (different bcs)

N.lbc = -pi/2;
N.rbc = 5*pi/2;

tic; theta = N\0; toc

% plot the height (this one swings over the
% top
plot(-cos(theta))

%% make a "movie"

nt = 100;
lm = 1.0;
ts = linspace(tl,tr,nt)

tt = theta(ts);

for i = 1:nt
    zc = 0 + 1i*eps(1);
    zm = sin(tt(i)) + 1i*(-cos(tt(i))+eps(1));
    plot( [zc;zm], '-o')
    axis equal
    ylim([-1.2,1.2])
    xlim([-1.2,1.2])
    
    pause(lm/nt)
end
    