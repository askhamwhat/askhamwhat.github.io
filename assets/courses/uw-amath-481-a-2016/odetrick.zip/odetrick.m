%%%%%%
%
% Solve the Airy equation using 
% a homogenous Dirichlet boundary
% value solver.
%
% You can handle non zero Dirichlet
% boundary conditions by adding a 
% linear function to your unknown
% and modifying the ODE accordingly
% (see odetrick.pdf)
%
% It currently runs with N=1000 but
% the solution isn't really well resolved
% If your code is set up with sparse
% matrices it should be able to handle 
% N = 100000+ (you can run this by uncommenting
% the appropriate line below)
%
%%%%%%

% set up the airy equation

p = @(x) ones(size(x));
pp = @(x) zeros(size(x));
q = @(x) x;

f = @(x) zeros(size(x));

x0 = -30;
xN = 30;

% Dirichlet BCs

alpha = 1;
beta = 0;

fmod = @(x) f(x) + (beta-alpha)/(xN-x0)*pp(x) - q(x).*((beta-alpha)*(x-x0)/(xN-x0)+alpha);

N = 1000;
%N = 100000;
x = linspace(x0,xN,N+1);
xin = x(2:end-1);

A = fem1dmatdir(x0,xN,xin,p,q);
phi = fem1drhsdir(x0,xN,xin,fmod);

w = A\phi;

v = w + (beta-alpha)/(xN-x0)*(xin-x0).' + alpha;

plot(xin,v)
