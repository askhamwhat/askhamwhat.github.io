
%%% Floating point in MatLab (double precision)

%% eps(x) returns the distance from the 
%% given floating point number to the next
%% this gives a sense of the absolute accuracy
%% for representing numbers of that size

eps(1)
eps(5)
eps(10^6)

%% eps returns machine precision, which represents 
%% a bound on the relative accuracy for normal (as opposed
%% to subnormal) floating point numbers

eps

%% let's look at the relative accuracy for a 
%% wide range of numbers in the normal range

fvals = (1+rand(1,100)).*2.^(linspace(-1022,1022,100));

% we see that the relative error is bounded 
% by machine precision

figure
loglog(fvals,eps(fvals)./abs(fvals))
hold on
loglog(fvals,eps(1)*ones(size(fvals)),'r','LineWidth',2)

%% let's look at the relative accuracy for 
%% a wide range of numbers, including sub-normal
%% numbers

fvals = (1+rand(1,100)).*2.^(linspace(-1075,-900));

% we see that the relative error is no longer bounded
% by machine precision for sub-normal numbers

figure
loglog(fvals,eps(fvals)./abs(fvals))
hold on
loglog(fvals,eps(1)*ones(size(fvals)),'r','LineWidth',2)

%%% what's the largest representable number?

2-2^-52 % less than 2
2-2^-53 % = 2 in floating point

2^1023 % representable
2^1023*(2-2^-52) % representable
2^1023*(2-2^-53) % infinity (this gets entered as 2^1024)

%%% what's the smallest representable number?

2^-1074 %representable
2^-1075 %not representable (gives zero)
eps(0) % = 2^-1074
eps(2^-1074)/abs(2^-1074) % relative accuracy is bad

%%% catastrophic cancellation (loss of significance)
%%% sometimes significant digits are completely lost

%% example: relative error a+b+c

a = 1;
b = (1+rand())*2^-51;
c = -1;

% in exact arithmetic a+b+c = b
% but in floating point ...

format longE

a+b+c
b

% huge relative error
abs(b-(a+b+c))/abs(b)

% explore this effect for different sizes of b

bsave = zeros(52,1);
relsave = zeros(52,1);

for i = 1:52
    a = 1;
    b = (1+rand())*2^-i;
    c = -1;
    
    bsave(i) = b;
    relsave(i) = abs(b-(a+b+c))/abs(b);
end

figure 
loglog(bsave,relsave)

