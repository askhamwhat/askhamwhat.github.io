
%% build an arbitrary matrix with large condition number
%% and solve

n = 500;
[U,S,V] = svd(randn(n,n));
sigs = logspace(0,-10,n);
A = U*diag(sigs)*V';
x = randn(n,1);
b = A*x;

% condition number

kappa = cond(A)

% solve system

xtilde = A\b;

% residual error

residual = norm(A*xtilde-b)

% residual times condition number

bound = residual*kappa

% error

error = norm(xtilde-x)

