function str = floating_pt_str(x)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% For pedagogical purposes
%
% This routine returns a string
% of 1's and 0's corresponding
% to the 64bit floating point 
% representation of the input
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

str1 = num2str(x,'%bx');
str1
str = dec2bin(hex2dec(str1),64);
