

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Test accuracy of Taylor 
% series approximation for e^x
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = 60;
x = 20;

% what do terms of sum for e^x look like

xi = 1;
ifac = 1;
terms = zeros(n,1);

for i = 1:n
    xi = xi*x;
    ifac = ifac*i;
    terms(i) = xi/ifac;
end

% get pretty large for intermediate i
semilogy(terms)

max(abs(terms))
exp(x)
exp(-x) % e^-x is much smaller than largest term in sum

ex = exp_taylor(x,n);
emx = exp_taylor(-x,n);

aex = abs(ex-exp(x))
rex = aex/exp(x)

aemx = abs(emx-exp(-x))
remx = aemx/exp(-x)

emxinv = 1/ex;
aemxinv = abs(emxinv-exp(-x))
remxinv = aemxinv/exp(-x)

