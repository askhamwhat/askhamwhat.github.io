
function e = exp_taylor(x,n)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This returns the Taylor series 
% approximation of e^x of order n
%
% THIS IS FOR EDUCATIONAL PURPOSES ONLY
%
% the algorithm is crazy unstable for
% large, negative x
%
% it's also not the most stable way
% to implement this algo.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

e = 1;
ifac = 1.0;
xi = 1.0;
for i = 1:n
    ifac = ifac*i;
    xi = xi*x;
    e = e + xi/ifac;
end
    
