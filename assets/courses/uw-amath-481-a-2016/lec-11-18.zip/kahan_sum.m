
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Kahan sum Forward Euler 
%
% Solve y' = -y 
% y(0) = 1
% exact solution e^-y
% 
% do standard Forward Euler and 
% compensated (Kahan) summation
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nn = 24;

% straight-forward computation

Ns = zeros(nn,1);
errs = zeros(nn,1);

for n = 1:nn
    N = 2^n;
    Ns(n) = N;
    
    y0 = 1;
    y = single(y0); % force single precision arithmetic
    h = 1.0/N;
    for i = 1:N
        f = -y;
        y = y + h*f;
    end
    errs(n) = abs(y-exp(-1.0));
end

% using Kahan summation

Nsk = zeros(nn,1);
errsk = zeros(nn,1);

for n = 1:nn
    N = 2^n;
    Nsk(n) = N;
    
    y0 = 1;
    y = single(y0); % force single precision arithmetic
    yc = single(0.0); % correction term
    h = 1.0/N;
    for i = 1:N
        f = -y;
        tempdy = h*f + yc;
        tempy = y + tempdy;
        yc = (y-tempy) + tempdy; %would be zero in exact arithmetic
        y = tempy;
    end
    errsk(n) = abs(y-exp(-1.0));
end

figure
loglog(Ns,errs)
hold on
loglog(Nsk,errsk)