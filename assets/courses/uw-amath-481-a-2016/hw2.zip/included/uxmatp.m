function A = uxmatp(n)

% build the centered differences approximation
% to the derivative for a 1D uniform, periodic
% grid with n points.

% to get true matrix, scale by 1/dx, where
% dx = grid spacing

A = spdiags([ ones(n,1), - ones(n,1)], [1 -1] , n, n);
A(1,n) = -1;
A(n,1) = 1;
A = 0.5*A;