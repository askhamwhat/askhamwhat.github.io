
function A = uxmatp2d(n)

%%%% build the 2nd order centered finite difference matrix
%%%% of size n^2 x n^2, in sparse format.

%%%% Output: A, which gives  d/dx u = A u

%% 2d periodic boundary conditions...

A1d = uxmatp(n);
I1d = speye(n);

A = kron(A1d,I1d);
