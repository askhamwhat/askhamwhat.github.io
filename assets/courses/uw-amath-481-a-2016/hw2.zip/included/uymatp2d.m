
function A = uymatp2d(n)

%%%% build the 2nd order centered finite difference matrix
%%%% of size n^2 x n^2, in sparse format.

%% 2d periodic boundary conditions...

  A = [];
