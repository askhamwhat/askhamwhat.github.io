
function omegap = fvortstream(t,omega,params)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% 
% Computes [psi,omega] + nu lap omega
% for the current omega
%
% first, it computes psi as 
% the solution of 
%      - lap psi = omega
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% print out the current time 
% (I do this to see the progress of the code,
% may be unnecessary at FFT speeds)

t

% domain

L = params{1};
N = params{2};
nu = params{3};
Ax = params{4};
Ay = params{5};
Alap = params{6};
lext = params{7};
uext = params{8};
pext = params{9};
qext = params{10};

%% solve lap psi = - omega

omegaext = [omega ; 0];
psiext(qext) = -uext\(lext\(omegaext(pext)));
psi = psiext(1:end-1);
psi = psi';

% compute the necessary derivatives

psix = Ax*psi;
psiy = Ay*psi;
omegax = Ax*omega;
omegay = Ay*omega;
omegalap = Alap*omega;

% set omegap = [psi,omega] + nu lap omega

omegap = psix.*omegay - psiy.*omegax + nu*omegalap;
