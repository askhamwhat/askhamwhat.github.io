
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% In this driver file, we use the 
% ode45 integrator to solve the 
% vorticity-streamfunction formulation
% of the navier-stokes equations on 
% a 2D periodic box
%
% Most of the work is done by the 
% function defined in fvortstream.m
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set up geometry

L = 1;
N = 256; % number of grid points in one direction
N2 = N^2; % total number of grid points

% diffusion parameter

nu = .001;

% time discretization

t0 = 0;
T = 5;

NT = 100;

% tspan is the set of times at
% which we request the solution.
% ode45 generally uses many more time
% steps to get an accurate solution
% but we could run out of storage if 
% we kept all of the intermediate steps

tspan = linspace(t0,T,NT);

% space discretization

x = linspace(-L,L,N+1); % width 2L/N
x = x(1:end-1);
y = x;

% meshgrid gives values of x and y in matrix form

[xx,yy] = meshgrid(x,y);

% we can reshape to get these values in vectors
% (taken one column of the original matrix at a time)

xxv = reshape(xx,N2,1);
yyv = reshape(yy,N2,1);

%% initial condition for omega


% made up of a sum of gaussians.
% delta determines the width... should be sufficiently 
% small so that the Gaussian is nearly machine precision
% near the boundary

delta = 1/100;

% sum of three gaussians with centers determined 
% by (xc1,yc1), etc.

xc1 = -0.2;
yc1 = -0.2;
xc2 = -0.4;
yc2 = -0.4;
xc3 = 0.3;
yc3 = 0.3;

% scale the gaussians by 1/sqrt(delta)

c1 = 1/sqrt(delta);
c2 = 1/sqrt(delta);
c3 = -2/sqrt(delta);

% (need c1+c2+c3 = 0)

% how the initial condition is defined

omega0 = c1*exp(-((xx-xc1).^2 + (yy-yc1).^2)/delta) ...
    + c2*exp(-((xx-xc2).^2 + (yy-yc2).^2)/delta) ...
    + c3*exp(-((xx-xc3).^2 + (yy-yc3).^2)/delta);

% plot the initial condition

figure

h = pcolor(xx,yy,omega0)
set(h,'EdgeColor','none')
title('initial condition')

% set up derivative matrices (using finite-differences here)
% this can be removed when changing to a FFT-based code...

dx = 2*L/N;

Ax = uxmatp2d(N)/dx; %  Ax*psi = d/dx psi
Ay = uymatp2d(N)/dx; % Ay*psi = d/dy psi
Alap = lapumatp2d(N)/(dx^2); % Alap*psi = lap psi
Alapext = lapumatp2d_ext(N)/(dx^2); % matrix for solving 
                                    % -lap psi = omega
                                    % where int psi = int omega.

% pre-compute lu factorization of Alapext so that solves are
% fast. Alapext is sparse. Allowing for column and row permutations
% (represented by pext and qext) makes lu more efficient.
                                    
[lext,uext,pext,qext] = lu(Alapext,'vector');

% parameters sent to fvortstream
% things needed to compute d/dt omega = [psi,omega] + nu lap omega
% (note that you have to compute psi via -lap psi = omega each time,
% see fvortstream.m for more)

% you will likely only need L, N, and nu for the FFT implementation.

params{1} = L;
params{2} = N;
params{3} = nu;
params{4} = Ax;
params{5} = Ay;
params{6} = Alap;
params{7} = lext;
params{8} = uext;
params{9} = pext;
params{10} = qext;

% write initial condition as a vector (ode45 works on
% vectors of unkowns)

omega0v = reshape(omega0,N2,1);

% call ode45.
% tspan determines where we record solution (except if tspan is
% length 2, in which case you get every time step in omegaout ...
% do not use tspan of length 2 for a problem with many steps
% and a large unknown, like this one).

% much of the work is done in fvortstream.m

[tout,omegaout] = ode45(@(t,omega) fvortstream(t,omega,params),tspan,omega0v);

% can go back and recompute the psi corresponding to each omega...

psiout = zeros(size(omegaout));

for i = 1:length(tout)-1
    
    % compute psi by solving - lap psi = omega
    % The system Alapext is equivalent to solving
    % (Alap + ww^T)x = b, with w = ones(N2,1) except
    % Alapext is sparse ...
    
    omegaext = [omegaout(i,:)' ; 0];
    psiext(qext) = -uext\(lext\(omegaext(pext)));
    psi = psiext(1:end-1);
    psi = psi';
    psiout(i,:) = psi';
end

% get bounds for plotting purposes...

psimin = min(min(psiout));
psimax = max(max(psiout));

omegamin = min(min(omegaout));
omegamax= max(max(omegaout));

vcontour = linspace(psimin,psimax,20);

for i = 1:length(tout)-1

    % grab values for this time step
    
    psi = psiout(i,:)';
    omega = omegaout(i,:)';
    
    % compute derivatives of psi
    % (can use these to visualize the velocity field
    % u = grad perp psi)
    
    psix = Ax*psi;
    psiy = Ay*psi;
    
    % reshape psi and omega to meshgrid
    % dimensions
    
    psi2 = reshape(psi,N,N);
    omega2 = reshape(omega,N,N);
    
    %% plot in various ways (can turn on and off)
    
    hold off
    
    % these two lines do either a heatmap of 
    % psi or omega
    
    %h=pcolor(xx,yy,psi2)
    h=pcolor(xx,yy,omega2)
    
    set(h,'EdgeColor','none') %makes it easier to see heatmap
    caxis([omegamin omegamax]) %fixes range of heatmap colors
    %caxis([psimin psimax]) %different range of heatmap colors
    hold on
    
    % this line plots the stream lines (lines of constant psi)
    contour(xx,yy,psi2,vcontour,'-k','LineWidth',2)
    
    % this line plots the velocity field
    %quiver(xxv,yyv,psiy,-psix)
    
    % the pause allows you time to see the result
    % for each i in the for loop
    % the effect is that you essentially get a movie
    % of the result
    pause(.1)
end