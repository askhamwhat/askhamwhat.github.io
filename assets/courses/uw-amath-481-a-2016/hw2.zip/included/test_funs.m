
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This is the testing driver for
% the FFT 2D based differentiation
% routines and centered differences 
% routines written for homework 2.
%
% Do NOT modify
%
% However, feel free to copy to another
% file so you can do testing before 
% submitting to SCORELATOR
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% define geometry

L = 1;
N = 16; % number of grid points in one direction (this is 
        % under-resolved. to compare to centered differences
        % use a larger N. this small N is for the sake of 
        % scorelator's servers and testing that the functions
        % are taking the right steps)
        
N2 = N^2; % total number of grid points

% space discretization

x = linspace(-L,L,N+1); % width 2L/N
x = x(1:end-1);
y = x;

% meshgrid gives values of x and y in matrix form

[xx,yy] = meshgrid(x,y);

% we can reshape to get these values in vectors
% (taken one column of the original matrix at a time)

xxv = reshape(xx,N2,1);
yyv = reshape(yy,N2,1);

% define f

% made up of a sum of gaussians.
% delta determines the width... should be sufficiently 
% small so that the Gaussian is nearly machine precision
% near the boundary

delta = 1/100;

% sum of three gaussians with centers determined 
% by (xc1,yc1), etc.

xc1 = 0.1;
yc1 = 0.1;
xc2 = -0.1;
yc2 = -0.1;
xc3 = 0.3;
yc3 = 0.3;

% scale the gaussians by 1/sqrt(delta)

c1 = 1/sqrt(delta);
c2 = 1/sqrt(delta);
c3 = -2/sqrt(delta);

% (need c1+c2+c3 = 0)

% define f in vector form

f = c1*exp(-((xxv-xc1).^2 + (yyv-yc1).^2)/delta) ...
    + c2*exp(-((xxv-xc2).^2 + (yyv-yc2).^2)/delta) ...
    + c3*exp(-((xxv-xc3).^2 + (yyv-yc3).^2)/delta);

% call various routines

dxf = real(dxf_fft2d(f,L));
lapf = real(lapf_fft2d(f,L));
u = real(lapinvf_fft2d(f,L));

Ay = uymatp2d(N);
dx = (2.0*L)/N;
dyf = Ay*f;
isspAy = double(issparse(Ay));

% write out results to A7.dat - A11.dat

save A7.dat dxf -ascii
save A8.dat dyf -ascii
save A9.dat lapf -ascii
save A10.dat u -ascii
save A11.dat isspAy -ascii
