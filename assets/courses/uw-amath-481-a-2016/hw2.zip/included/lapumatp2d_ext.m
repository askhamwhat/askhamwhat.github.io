
function Aext = lapumatp2d_ext(n)

%%%% build the 2nd order centered finite difference matrix
%%%% of size n^2 +1  x n^2 +1, in sparse format with a modification
%%%% to make it full rank

%% solves 
%% lap u = f
%% where sum(u) = sum(f)

%% let A be the centered differences approximations
%% to lap u with periodic boundary conditions
%% this routine returns Aext given by

%%           
%%  Aext =   [ A   w  ]
%%           [ w^T -1 ]
%%

%% 2d periodic boundary conditions...

A1d = uxxmatp(n);
I1d = speye(n);

n2 = n*n;

Aext = spalloc(n2+1,n2+1,7*n2+1);

Aext(1:end-1,1:end-1) = kron(A1d,I1d) + kron(I1d,A1d);

w = ones(n2,1);

Aext(end,1:end-1) = w';
Aext(1:end-1,end) = w;

Aext(end,end) = -1;


