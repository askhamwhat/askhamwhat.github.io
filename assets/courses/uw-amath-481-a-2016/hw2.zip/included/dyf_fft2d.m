
function dyf = dyf_fft2d(f,L)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Input:
%  f - vector of grid values of 
%      a function on the box
%      [-L,L] x [-L,L]
%
%  the underlying grid is assumed
%  uniform in x and y, with the
%  same number of discretization
%  points in each direction
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N2 = length(f);
N = sqrt(N2);

kscalex = 1i*[0:N/2 -N/2+1:-1]*pi/L.';
kscaley = kscalex;

[kx,ky] = meshgrid(kscalex,kscaley);

fgrid = reshape(f,N,N);

fhat = fft2(fgrid);

dyfhat = ky.*fhat;

dyf = ifft2(dyfhat);

dyf = reshape(dyf,N2,1);

