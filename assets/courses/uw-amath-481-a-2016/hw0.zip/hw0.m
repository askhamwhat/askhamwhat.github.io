
%%% hw0 - simple pendulum with forward Euler

%%% NOTE: this is written for a harmonic oscillator
%%% you must change it to the equations for a pendulum
%%% and the parameters requested in the assignment

%% parameters

t0 = 0.0;
tN = 6.0;
N = 2300;
k = 2.0; % spring constant
m = 1.0; % mass
c = 0.0; % damping
theta0 = 1.3;
thetadot0 = 0.0;

%% derivative

f = @(y,t) [y(2); -k/m*y(1) - c/m*y(2)];

%% time-stepping

t = linspace(t0,tN,N+1);
dt = t(2)-t(1);
y = zeros(2,N+1);
y(:,1) = [theta0; thetadot0];

for j = 1:N
    y(:,j+1) = y(:,j) + dt*f(y(:,j),t(j));
end

E = 0.5*k*y(1,:).^2 + 0.5*m*y(2,:).^2;

%% make sure data is in columns and write to ascii files

A1 = y(1,:)';
A2 = y(2,:)';
A3 = E';

save A1.dat A1 -ascii
save A2.dat A2 -ascii
save A3.dat A3 -ascii