%%% The least squares problem for 
%%% recovering polynomial coefficients is 
%%% more stable in the chebyshev basis than the
%%% monomial basis 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% In this file, we set up a grid of random points 
% in [-1,1] and then do the least square fit of 
% a polynomial function on those points using 
% the monomial basis and the chebyshev basis 
%
% The fit is observed to be much more stable using
% the chebyshev basis 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% number of points
N = 100;
x = -1 + 2*rand(N,1);

% degree of fit (if M is too close to N then I don't think
% random points will work well anymore)
M = 20;
v_mon = zeros(N,M+1);
for i = 1:M+1
    v_mon(:,i) = x.^(i-1);
end

% chebpols is something I wrote real quick
% b/c matlab's built-in is super slow. there
% are more stable evaluation methods (e.g. in chebfun)
vcheb = chebpols(x,20);

cond(v_mon)
cond(vcheb)

sigma = 0.01; % noise level
f = x.^3 + 0.5*x.^2 + sigma*rand(N,1);

c1 = v_mon\f
c2 = vcheb\f

