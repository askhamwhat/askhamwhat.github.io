
%%%%%%%%%%%%%%
% 
% Explore Vandermonde matrices
% and condition numbers
%
%
%%%%%%%%%%%%%%%

%%% monomial basis

%% what it looks like

N = 5;
x = linspace(-1,1,N+1);
V = vander(x)

%% large condition number

N = 40;
x = linspace(-1,1,N+1);
V = vander(x);
cond(V)

%%% Chebyshev basis

%% with Chebyshev basis it is stable

N = 1000;
tt = linspace(0,pi,N+1);
x = cos(tt)'; % Chebyshev points
V = chebpols(x,N+1);
cond(V)
