%%%%%%%%%%%%%%%%%%%%
%
% Code used for examples in
% chapter 5 of ATAP
%
%%%%%%%%%%%%%%%%%%%%

%% lagrange polynomial

d = domain(-1,1); 
s= linspace(-1,1,7); 
s = chebpts(7);
y= [0 0 0 0 0 1 0];
p = interp1(s,y,d); plot(p), hold on, plot(s,p(s),'.k')

%% timings

x = chebfun('x');
f = tanh(20*sin(12*x)) + 0.02*exp(3*x).*sin(300*x);

length(f)

plot(f)

x = linspace(-1,1,10000);
tic; fv = f(x); toc

%% crazier function

ff = @(x) sin(1e5*x); 
p = chebfun(ff,1e6+1);

xx = linspace(0,.0001,100);
tic; pp = p(xx); toc

plot(xx,pp,'.')
norm(ff(xx)-pp,inf)/norm(ff(xx),inf) % condition number of 1e5 so this is good
