
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% code used for examples 
% in chapter 3 of ATAP
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% chebpoly gives the 
%% chebyshev polynomial
%% of degree n

for n = 1:6
    T{n} = chebpoly(n);
end

figure
for n = 1:6
    subplot(3,2,n)
    plot(T{n},'.-')
end

%% display coefficients
%% of cheby polynomials in
%% monomial basis 1,x,x^2,x^3, etc.

for n = 1:6
    disp(poly(T{n}))
end

%% look at chebyshev 
%% coefficients for a few
%% functions

x = chebfun('x');
f = exp(x);
a = chebpoly(f);

a(end:-1:1)'

%% a wiggly function

figure
f = sin(6*x) + sin(60*exp(x));
plot(f)

a = chebpoly(f);
semilogy(abs(a(end:-1:1)))
length(f)

%% function with 'nearby'
%% singularities

f = 1./(1+1000*(x+.5).^2) + 1./(sqrt(1+1000*(x-.5).^2));
plot(f)

% chebpolyplot wraps up
% chebpoly and semilogy
chebpolyplot(f)

