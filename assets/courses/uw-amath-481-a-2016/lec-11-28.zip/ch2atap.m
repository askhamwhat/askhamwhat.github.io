
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Codes used to generate
% chapter 2 of ATAP
% examples
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = 16;

tt = linspace(0,pi,n+1);

% plot (2n)th roots of unity

zz = exp(1i*tt);
plot(zz,'.-k')

% the Chebyshev points are
% the real parts of these points

xx = real(zz);

% also equal to cos of original angles

xx1 = cos(tt);
norm(xx-xx1)

% also given by chebfun function
% chebpts (in different order)

xx = xx(end:-1:1).';
xx2 = chebpts(n+1);
norm(xx-xx2)

%% add chebyshev points to the plot
%% adding the machine epsilon times i
%% part forces matlab to interpret
%% as complex values
hold on
for i = 1:length(xx)
    plot([xx(i)+eps(1)*1i, zz(end+1-i)+eps(1)*1i],'k')
end
plot(xx,0*xx,'.r')

%% example chebfun
%% based on interpolants at 
%% chebyshev nodes

hold off
x = chebfun('x');
f = sign(x) - x/2;
plot(f,'k')

% interpolant through 6 chebyshev 
% points (degree 5 polynomial)

p6 = chebfun(f,6);
hold on
plot(p6,'.-')

% interpolant through 26 points

hold off
plot(f,'k')
p26 = chebfun(f,26);
hold on
plot(p26,'.-')

% more complicated function
% and degree 100 (101 point)
% interpolant

hold off
f = sin(6*x) + sign(sin(x+exp(2*x)));
plot(f,'k')
p = chebfun(f,101);
hold on 
plot(p,'-')

% look at how p and f
% are stored

p
f

% chebfun uses some fancy
% algorithms to chop up f
% like that

% can also create a chebfun based on
% data at chebyshev points

% here we use random data
% in [-1,1]

fdata = 2*rand(100,1)-1;

% the chebyshev interpolant is
% very robust 

hold off
p = chebfun(fdata);
plot(p,'.-k')

max(p)
min(p)

%% compare this to
%% equispaced interpolation

n = 20;
xu = linspace(-1,1,n+1)';
fdata = 2*rand(n+1,1)-1;
pp = polyfit(xu,fdata,n);
xfine = linspace(-1,1,1000);
ppfine = polyval(pp,xfine);

hold off
plot(xfine,ppfine)
hold on
plot(xu,fdata,'.')

max(ppfine)
min(ppfine)

%% what about smooth data?
%% chebyshev is still superior

% the famous Runge function

f = @(x) 1./(1+25*x.^2);

% start with n = 8
% try larger

n = 100;

ftrue = chebfun(f);
fcheb = chebfun(f,n+1);

subplot(1,2,1)

hold off
plot(ftrue,'k')
hold on
plot(fcheb,'.-')

xu = linspace(-1,1,n+1)';
fdata = f(xu);
pp = polyfit(xu,fdata,n);
xfine = linspace(-1,1,1000);
ppfine = polyval(pp,xfine);

subplot(1,2,2)

hold off 
plot(ftrue,'k')
hold on
plot(xfine,ppfine)
plot(xu,fdata,'.')