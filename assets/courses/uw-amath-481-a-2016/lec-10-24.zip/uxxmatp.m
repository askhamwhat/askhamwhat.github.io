
function Axx = uxxmatp(L,N)

%% build the matrix for 1d periodic second
%% derivatives

% domain [-L,L]

% dimension in x is N

x = linspace(-L,L,N+1);
dx = x(2)-x(1);

% set up the matrix of 1-d centered differences
% for periodic BC's

Axx = spdiags(ones(N,2),[1 -1],N,N) - 2*speye(N);

Axx(1,N) = 1;
Axx(N,1) = 1;

Axx = Axx/(dx^2);