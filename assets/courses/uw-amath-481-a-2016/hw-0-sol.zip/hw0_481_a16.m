
%%% hw0 - simple pendulum with forward Euler

%% parameters

t0 = 0.0;
tN = 10.0;
N = 10000;
g = 9.8;
l = 1.0;
theta0 = pi/4.0;
thetadot0 = 0.0;

%% derivative

f = @(y,t) [y(2); -g/l*sin(y(1))];

%% time-stepping

t = linspace(t0,tN,N+1);
dt = t(2)-t(1);
y = zeros(2,N+1);
y(:,1) = [theta0; thetadot0];

for j = 1:N
    y(:,j+1) = y(:,j) + dt*f(y(:,j),t(j));
end

E = g*l*(1-cos(y(1,:))) + 0.5*l*l*y(2,:).^2;

%% make sure data is in columns and write to ascii files

A1 = y(1,:)';
A2 = y(2,:)';
A3 = E';

save A1.dat A1 -ascii
save A2.dat A2 -ascii
save A3.dat A3 -ascii