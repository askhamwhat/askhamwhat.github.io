
%%% hw0 - simple pendulum with forward Euler

%% parameters

t0 = 0.0;
tN = 10.0;
N0 = 10000;
g = 9.8;
l = 1.0;
theta0 = pi/4.0;
thetadot0 = 0.0;

%% derivative

f = @(y,t) [y(2); -g/l*sin(y(1))];

nN = 5;
Nsave = zeros(nN,1);
err = zeros(nN,1);

for jjj = 1:nN

    N = N0*2^(jjj-1);
    
    %% time-stepping

    t = linspace(t0,tN,N+1);
    dt = t(2)-t(1);
    y = zeros(2,N+1);
    y(:,1) = [theta0; thetadot0];

    for j = 1:N
        y(:,j+1) = y(:,j) + dt*f(y(:,j),t(j));
    end

    E = g*l*(1-cos(y(1,:))) + 0.5*l*l*y(2,:).^2;
    
    Nsave(jjj) = N;
    err(jjj) = abs(E(N+1)-E(1));
end

% just plotting the numbers

figure
plot(Nsave,err)

% plottig on a log scale to compare
% with various modes of decay

figure
loglog(Nsave,err,'g')
hold on
loglog(Nsave,1./Nsave,'b')
loglog(Nsave,1./(Nsave.^2),'r')
loglog(Nsave,exp(-Nsave/5000),'m')

% plotting the ratio

figure 
loglog(Nsave,err.*Nsave)
hold on
loglog(Nsave,err.*Nsave.^2)
