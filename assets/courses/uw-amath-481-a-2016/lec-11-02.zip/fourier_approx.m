
close all

%%% Fourier series approximation to a function

% interval [-L,L]

L = 1;

% N used for fine grid, computing coefficients

N = 2^10;

% the fft actually computes the sum
% for k = 0, ... N-1
% but due to "aliasing" the values of
% the exponentials for k > N/2 match up
% with exponentials with negative coefficients

kalias = [0:N/2 -N/2+1:-1];
kscale = (kalias*pi/L).';

% the factor that you get when differentiating

kder = 1i*kscale;
kder2 = -kscale.^2;

% function to approximate

f = @(x) exp(5*sin(x*pi/L));
f = @(x) abs(sin(x*pi/L));

x = linspace(-L,L,N+1);

xin = x(1:end-1);
fin = f(xin);

figure

plot(xin,fin);

% grab coefficients of f

a = fft(fin);

figure

semilogy(abs(fftshift(a))/max(abs(fin)))

time = 10;

ntests = 5;
ntests = 25;

figure

plot(xin,fin,'--')
hold on

err = zeros(ntests,1);
ncoeffs = zeros(ntests,1);

for i = 1:ntests
    ncoeff = i;
    trunc_mask = (abs(kalias) <= ncoeff);
    atrunc = a.*trunc_mask;
    ftrunc = ifft(atrunc);
    pause(time/ntests)
    plot(xin,ftrunc)
    hold on
    err(i) = max(abs(ftrunc-fin))/max(abs(fin));
    ncoeffs(i) = ncoeff;
end
    
figure

semilogy(ncoeffs,err)