
%%% Solve an ODE with Fourier series

% consider u'' - u = -f on [-L,L]
% with f periodic. Want to compute a 
% periodic solution u.

L = 1;
N = 2^10;

% the fft actually computes the sum
% for k = 0, ... N-1
% but due to "aliasing" the values of
% the exponentials for k > N/2 match up
% with exponentials with negative coefficients

kscale = [0:N/2 -N/2+1:-1]*pi/L.';

% the factor that you get when differentiating

kder = 1i*kscale;
kder2 = -kscale.^2;

% to invert the equation, just divide through
% (see notes)

kinv = 1./(kder2-1);

% our right hand side

f = @(x) sin(3*pi*x/L) + exp(-30*x.^2);

x = linspace(-L,L,N+1);

xin = x(1:end-1);
fin = f(xin);

figure

plot(xin,fin);

% grab coefficients of -f

a = fft(-fin);

figure

semilogy(abs(fftshift(a)))

% compute coefficients of u using the formula

b = a.*kinv;

% obtain u using the inverse FFT

uin = ifft(b);

% plot solution

figure

plot(xin,uin,'r','LineWidth',2)

% test solution

% get second derivative matrix

Axx = uxxmatp(L,N);

figure

plot(xin,-fin,'g','LineWidth',2)
hold on

plot(xin,Axx*(uin')-uin','--b','LineWidth',2)

