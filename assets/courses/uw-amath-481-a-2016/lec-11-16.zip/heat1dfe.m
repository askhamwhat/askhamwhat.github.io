
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Heat equation example in 1D (periodic)
%
% Forward Euler version
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% parameters

L = 1; % solve on grid [-L,L]
N = 100; % number of spatial grid points
t0 = 0; % start time
T = 1; % end time
kappa = 0.125; % thermal diffusivity

%% initial condition u_0 = f(x)
f = @(x) sin(3*pi*x/L)+2;

%% set up grid
x = linspace(-L,L,N+1);
x = x(1:end-1); % cut-off last point due to periodicity
dx = x(2)-x(1);

% spacing in time
dt = 0.9*dx/kappa;
dt = 0.6*dx^2/kappa;
dt = 0.4*dx^2/kappa;

NT = ceil((T-t0)/dt);

%% initialize
u0 = f(x)';

%% get finite difference matrix
A = uxxmatp(N)*kappa/(dx^2);

u = zeros(N,NT+1);
t = zeros(NT+1,1);
t(1) = t0;
u(:,1) = u0;

for i = 1:NT
    u(:,i+1) = u(:,i)+dt*A*u(:,i);
    t(i+1) = t(i)+dt;
end

mesh(t,x,u) 