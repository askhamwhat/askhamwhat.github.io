
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Nonlinear Schrodinger in 1D (periodic)
%
% Forward Euler version
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% parameters

L = 30; % solve on grid [-L,L]
N = 200; % number of spatial grid points
t0 = 0; % start time
T = 3; % end time

%% initial condition u_0 = f(x)
f = @(x) sech(x);

%% set up grid
x = linspace(-L,L,N+1);
x = x(1:end-1); % cut-off last point due to periodicity
dx = x(2)-x(1);

% spacing in time
dt = 0.9*dx;
%dt = 0.6*dx^2;
dt = 0.4*dx^2;
%dt = 0.05*dx^2;

NT = ceil((T-t0)/dt);

%% get finite difference matrix
A = uxxmatp(N)/(dx^2);

u0 = f(x)';

u = zeros(N,NT+1);
t = zeros(NT+1,1);
t(1) = t0;
t(2) = t0+dt;
u(:,1) = u0;

for i = 1:NT
    u(:,i+1) = u(:,i)-1i*dt*0.5*A*u(:,i) ...
        -1i*dt*(conj(u(:,i)).*u(:,i)).*u(:,i);
    t(i+1) = t(i)+dt;
end

mesh(t,x,real(u))