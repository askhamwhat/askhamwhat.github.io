
function A = lapumatp2d(n)

%%%% build the 2nd order centered finite difference matrix
%%%% of size n^2 x n^2, in sparse format.

%% 2d periodic boundary conditions...

A1d = uxxmatp(n);
I1d = speye(n);

A = kron(A1d,I1d) + kron(I1d,A1d);
