
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% The one way wave equation
%
% u_t = u_x
%
% Initial condition: 
%
% u(x,0) = sech(4x) 
%
% Solve with:
%
% centered differences in space
% backward Euler in time
% (always satisfies CFL condition
% and always stable)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% cfl number

lambda = 1.1;
%lambda = 0.9;
%lambda = 0.5;
%lambda = 0.25;

% domain is [-L,L]
L = 8;
N = 200;

% time
t0 = 0;
T = 2.3;

x = linspace(-L,L,N+1);
x = x(1:end-1);

dx = x(2)-x(1);

Ax = uxmatp(N);
Ax = Ax/dx;

dt = lambda*dx;

NT = ceil((T-t0)/dt);

% two initial conditions
% (only need one here)

u0 = sech(4*x);
u1 = sech(4*(x+dt));

u = zeros(N,NT+1);
t = zeros(NT+1,1);
t(1) = t0;
t(2) = t0+dt;
u(:,1) = u0;
%u(:,2) = u1;

% backward euler u^n+1 = u^n + dt*Ax*u^n+1
% (I-dt*Ax)u^n+1 = u^n

B = speye(N)-dt*Ax;

%for i = 2:NT
for i = 1:NT
    u(:,i+1) = B\u(:,i);
    t(i+1) = t(i)+dt;
end

mesh(t,x,u) 
