
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Nonlinear Schrodinger in 1D (periodic)
%
% Leap frog version
%
% breather solution
%
% sech(x)*exp(0.5*i*t)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% parameters

L = 30; % solve on grid [-L,L]
N = 400; % number of spatial grid points
N = 200; % number of spatial grid points
t0 = 0; % start time
T = 8*pi; % end time

%% initial condition u_0 = f(x)
f = @(x) sech(x);

%% set up grid
x = linspace(-L,L,N+1);
x = x(1:end-1); % cut-off last point due to periodicity
dx = x(2)-x(1);

% spacing in time
dt = 0.1*dx;
%dt = 0.6*dx^2;
%dt = 0.4*dx^2;
%dt = 0.1*dx^2;
%dt = 0.05*dx^2;

NT = ceil((T-t0)/dt);

%% get finite difference matrix
A = uxxmatp(N)/(dx^2);

%% for leap frog, need two starting conditions

u0 = f(x)';

%% get second initial condition with
%% forward euler

u1 = u0 -1i*0.5*dt*A*u0 -1i*dt*(conj(u0).*u0).*u0;

u = zeros(N,NT+1);
t = zeros(NT+1,1);
t(1) = t0;
t(2) = t0+dt;
u(:,1) = u0;
u(:,2) = u1;

for i = 2:NT
    u(:,i+1) = u(:,i-1)-1i*dt*A*u(:,i) ...
        -1i*2*dt*(conj(u(:,i)).*u(:,i)).*u(:,i);
    t(i+1) = t(i)+dt;
end

mesh(t,x,real(u))