
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Heat equation example in 1D (periodic)
%
% Leap frog version
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% parameters

L = 1; % solve on grid [-L,L]
N = 100; % number of spatial grid points
t0 = 0; % start time
T = 1; % end time
T = .04; % end time
kappa = 0.125; % thermal diffusivity

%% initial condition u_0 = f(x)
f = @(x) sin(3*pi*x/L)+2;

%% set up grid
x = linspace(-L,L,N+1);
x = x(1:end-1); % cut-off last point due to periodicity
dx = x(2)-x(1);

% spacing in time
dt = 0.9*dx/kappa;
dt = 0.6*dx^2/kappa;
dt = 0.4*dx^2/kappa;

NT = ceil((T-t0)/dt);

%% get finite difference matrix
A = uxxmatp(N)*kappa/(dx^2);

%% for leap frog, need two starting conditions

u0 = f(x)';

%% get second initial condition with
%% forward euler

u1 = u0 + dt*A*u0;

u = zeros(N,NT+1);
t = zeros(NT+1,1);
t(1) = t0;
t(2) = t0+dt;
u(:,1) = u0;
u(:,2) = u1;

for i = 2:NT
    u(:,i+1) = u(:,i-1)+dt*2*A*u(:,i);
    t(i+1) = t(i)+dt;
end

mesh(t,x,u) 
