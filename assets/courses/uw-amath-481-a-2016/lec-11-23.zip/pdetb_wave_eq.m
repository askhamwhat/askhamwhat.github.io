
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MATLAB PDE Toolbox Example
%
% Note: this file uses features of the MatLab
% PDE Toolbox for R2016b and greater. Will not
% work without the toolbox and for earlier versions.
%
% We use the PDE Toolbox to solve the wave equation
% on a square (this is an example from the 
% toolbox documentation)
%
% The mathematical equation is the Wave equation
%
% u_tt - lap u = 0
%
% We solve on a box with Dirichlet BCs on two edges
% and Neumann BCs on two others. The Dirichlet BCs
% reflect wave and the Neumann BCs move freely.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Create the model object

N = 1; % number of equations
model = createpde(N); %object to store info about geometry,
                      %pde description, boundary conditions
                      
%% Load geometry                      
                      
geometryFromEdges(model,@squareg);

%% Specify the PDE to be solved

% the pde app can solve equations of the form 

% m (d/dt)^2 u + d (d/dt) u - div ( c grad u) + a u = f
% m, d, c, a, and f must be specified

% for the Wave equation: 
% m = 1, d = 0, c = 1, a = 0, and f = 0

specifyCoefficients(model,'m',1,...
                          'd',0,...
                          'c',1,...
                          'a',0,...
                          'f',0);
                      
%% Specify boundary conditions      

applyBoundaryCondition(model,'dirichlet','Edge',[2,4],'u',0);
applyBoundaryCondition(model,'neumann','Edge',([1 3]),'g',0);

%% This problem is an initial boundary 
%% value problem, so need initial conditions
%% define them here

%% uses a location structure with x and y 
%% stored in it

u0 = @(location) atan(cos(pi/2*location.x));
ut0 = @(location) 3*sin(pi*location.x).*exp(sin(pi/2*location.y));

%% Generate the mesh and plot it 

generateMesh(model,'Hmax',0.1);
pdeplot(model)

%% Set initial conditions for this mesh

setInitialConditions(model,u0,ut0);

%% define solution times

n = 31;
tlist = linspace(0,5,n);

%% Solve the problem

result = solvepde(model,tlist);
u = result.NodalSolution;

%% Create a movie 

figure
umax = max(max(u));
umin = min(min(u));
for i = 1:n
    pdeplot(model,'XYData',u(:,i),'ZData',u(:,i),'ZStyle','continuous',...
                  'Mesh','off','XYGrid','on','ColorBar','off');
    axis([-1 1 -1 1 umin umax]);
    caxis([umin umax]);
    xlabel x
    ylabel y
    zlabel u
    M(i) = getframe;
end

movie(M)