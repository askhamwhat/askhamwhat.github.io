
%%%%%%%%%%%%%%%%%%%
%
% After exporting from pdetool
% set filename in here and save geometry
%
%%%%%%%%%%%%%%%%%%

filename = 'classexample.mat';

g = decsg(gd,sf,ns);

save(filename,'g');