
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MATLAB PDE Toolbox Example
%
% Note: this file uses features of the MatLab
% PDE Toolbox for R2016b and greater. Will not
% work without the toolbox and for earlier versions.
%
% We use the MatLab PDE Toolbox to solve a problem 
% in fluid flow. In particular, we solve for the
% potential flow around an object 
%
% The mathematical equation is the Laplace equation
%
% \Delta \phi = 0
%
% where Neumann inflow and outflow conditions are 
% specified on the left and right boundary and 
% zero flux conditions are specified on the 
% wing and the top and bottom boundaries.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Create the model object

N = 1; % number of equations
model = createpde(N); %object to store info about geometry,
                      %pde description, boundary conditions
                      
%% Load geometry                      
                      
%pdetb_load_wing % script loads a wing obstacle into g
                 % specifies indices corresponding to obstacle
                 % and corresponding to outer box
                 
pdetb_load_obstacle2           

pdegplot(g,'EdgeLabels','on') % show edges with labels
                 
geometryFromEdges(model,g);

%% Specify the PDE to be solved

% the pde app can solve equations of the form 

% m (d/dt)^2 u + d (d/dt) u - div ( c grad u) + a u = f
% m, d, c, a, and f must be specified

% for the Laplace equation: 
% m = 0, d = 0, c = 1, a = 0, and f = 0

specifyCoefficients(model,'m',0,...
                          'd',0,...
                          'c',1,...
                          'a',0,...
                          'f',0);
                      
%% Specify boundary conditions      

% for our example, all of the boundary conditions are 
% Neumann, with different values 

% zero Neumann condition for the obstacle 
% and top and bottom boundaries
% these edges specified in obstacle_edges,
% top_box, and bottom_box vectors
 
applyBoundaryCondition(model,'Edge',obstacle_edges,'g',0);
applyBoundaryCondition(model,'Edge',top_box,'g',0);
applyBoundaryCondition(model,'Edge',bottom_box,'g',0);
 
% inflow at left boundary
applyBoundaryCondition(model,'Edge',left_box,'g',-1);

% outflow at right boundary

%applyBoundaryCondition(model,'Edge',right_box,'g',1);
applyBoundaryCondition(model,'Edge',right_box,'u',0);

%% Generate the mesh and plot it 

generateMesh(model,'Hmax',0.1);
pdeplot(model)

%% Solve the problem

result = solvepde(model);

%% Plot solution 

vpot = result.NodalSolution;
vxpot = result.XGradients;
vypot = result.YGradients;

pdeplot(model,'FlowData',[vxpot vypot])
pdeplot(model,'XYData',sqrt(vxpot.^2 + vypot.^2))