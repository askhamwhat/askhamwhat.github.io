%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Loads info about the 2 obstacle geometry
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('obstacle2.mat')


 
     obstacle_edges = [3;4;5;6;7;10;11;12];
     left_box = [8];
     right_box = [1];
     top_box = [9];
     bottom_box = [2];
     