
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Loads info about a "wing" geometry
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('wing.mat')
 
     obstacle_edges = [3;4;7;8;9];
     left_box = [5];
     right_box = [1];
     top_box = [2];
     bottom_box = [6];
     