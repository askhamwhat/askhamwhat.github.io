
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% The one way wave equation
%
% u_t = a(x) u_x
%
% Initial condition: 
%
% u(x,0) = sech(4x) 
%
% Solve with:
%
% upwinding in space
% forward Euler in time
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% domain is [-L,L]
L = 8;
N = 200;

% variable coefficient

a = @(x) -sin(pi*x/L);
%a = @(x) ones(size(x));

% initial condition

unaught = @(x) sech(4*x);

% time
t0 = 0;
T = 10;

x = linspace(-L,L,N+1);
x = x(1:end-1);
dx = x(2)-x(1);

%% build matrix, etc.

avals = a(x);
lambda = 0.7*max(abs(avals));

Axbd = uxmatpbd(N);
Axbd = Axbd/dx;
Axfd = uxmatpfd(N);
Axfd = Axfd/dx;

zs = zeros(size(avals));

%% upwinding matrix: using forward differences
%% or backward differences depends on sign of the
%% variable coefficient a(x)

Amat = diag(min(avals,zs))*Axbd + diag(max(avals,zs))*Axfd;

dt = lambda*dx;

NT = ceil((T-t0)/dt);

% two initial conditions
% (only need one here)

u0 = unaught(x);
u1 = unaught(x+dt);

u = zeros(N,NT+1);
t = zeros(NT+1,1);
t(1) = t0;
t(2) = t0+dt;
u(:,1) = u0;
%u(:,2) = u1;

%for i = 2:NT
for i = 1:NT
    u(:,i+1) = u(:,i)+dt*Amat*u(:,i);
    t(i+1) = t(i)+dt;
end

mesh(t,x,u) 
