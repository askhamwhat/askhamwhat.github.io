
%%% stability regions

fplus = @(z) zeros(size(z)); % replace these with
                             % your formulae for the
			     % roots
fminus = @(z) zeros(size(z));

g = @(z) max(abs(fplus(z)),abs(fminus(z)));

x = linspace(-5,5,2000);
y = linspace(-5,5,2000);

[X,Y] = meshgrid(x,y);
Z = X+1i*Y;

G = g(Z);

figure

contourf(X,Y,G,[1.05 1.05]) % change the two numbers to get a
                            % different level set
axis equal

x_yax = zeros(size(y));
y_xax = zeros(size(x));

hold on
plot(x_yax,y)
plot(x,y_xax)

