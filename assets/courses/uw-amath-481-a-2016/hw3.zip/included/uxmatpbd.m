function A = uxmatpbd(n)

% build the backward differences approximation
% to the derivative for a 1D uniform, periodic
% grid with n points.

% to get true matrix, scale by 1/dx, where
% dx = grid spacing

A = spdiags([ ones(n,1), - ones(n,1)], [0 -1] , n, n);
A(1,n) = -1;