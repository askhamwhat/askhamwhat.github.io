function A = uxmatpfd(n)

% build the forward differences approximation
% to the derivative for a 1D uniform, periodic
% grid with n points.

% to get true matrix, scale by 1/dx, where
% dx = grid spacing

A = spdiags([ ones(n,1), - ones(n,1)], [1 0] , n, n);
A(n,1) = 1;