
function [x,niter,xsave,ressave] = jacobi_iter(A,x0,b,nmax,tol)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Simple implementation of the jacobi
% iteration for solving Ax=b
%
% Should be compatible with sparse A
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% initialization

% iteration ---> x_k+1 = D^-1 (b- R*x_k)

D = spdiags(A,[0]);
[m,n] = size(A);
D = spdiags(D,[0],m,n);
R = A-D;

scale = norm(b);

x = x0;

% storage

ressave = zeros(nmax,1);
xsave = zeros(length(x),nmax);
niter = 1;

% check if starting x0 is good enough

ressave(1) = norm(b-A*x);
xsave(:,1) = x;
if (ressave(1) < tol*scale)
    ressave = ressave(1:1);
    xsave = xsave(:,1:1);
    return
end

for i = 2:nmax
    
    % update x
    
    niter = i;
    x = D\(b-R*x);
    
    % store
    
    ressave(i) = norm(b-A*x);
    xsave(:,i) = x;
    
    % check if tolerance reached
    
    if (ressave(i) < tol*scale)
        break
    end
end

ressave = ressave(1:niter);
xsave = xsave(:,1:niter);
