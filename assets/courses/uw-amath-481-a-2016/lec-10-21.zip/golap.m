%%% set up Laplacian matrix

% run with N = 50, 100, 500

N = 50;
N2 = N^2;
A = lapumatdir2d(N);

% get size of D^-1*R

if (N2 < 5000)
    d = spdiags(A,[0]);
    D = spdiags(d,[0],N2,N2);
    R = A-D;
    normest(D\R)
end

% random right hand side, initial vector

iseed = 314;
rng(iseed)

x0 = randn(N2,1);
b = randn(N2,1);

% parameters

nmax = 300;
tol = 1.0e-9;

% solve with jacobi

tic
[x,niter,xsave,ressave] = jacobi_iter(A,x0,b,nmax,tol);
toc

norm(b-A*x)/norm(b)

% solve with Gauss-Seidel

tic
[xgs,niter,xsave,ressave] = gauss_seidel_iter(A,x0,b,nmax,tol);
toc

norm(b-A*xgs)/norm(b)

% solve with conjugate gradients

% note that the required iterations grows with increasing N2

tic
xcg = pcg(-A,-b,tol,nmax);
toc

norm(b-A*xcg)/norm(b)

% solve with gmres

nrestart = 20;

tic
xgmres = gmres(A,b,nrestart,tol,nmax/nrestart);
toc

norm(b-A*xgmres)/norm(b)

% solve directly (using built in sparse stuff)

% Note that the system size is N2 above, we'll
% say n = N2, here.
% the direct method is O(n^(3/2)) while the others are O(Kn)
% where K is the number of iterations. Because K
% is so large for this example, the direct method
% is actually faster, even for n=N2=25000 (N=500)

tic 
xdir = A\b;
toc

norm(b-A*xdir)/norm(b)

% solve directly (without built in sparse stuff)

if (N2 < 4000)

Af = full(A);    
    
tic 
xdir = Af\b;
toc

norm(b-A*xdir)/norm(b)

end
