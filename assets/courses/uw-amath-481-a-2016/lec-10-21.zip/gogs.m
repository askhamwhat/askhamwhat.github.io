
%%%% diagonally dominant example

A = [4 -1 1; 4 -8 1; -2 1 5];

U = triu(A,1);
L = tril(A);

norm(L\U)

b = [7; -21; 15];

x0 = [1; 2; 2];

nmax = 30;

tol = 1.0e-9;

[x,niter,xsave,ressave] = gauss_seidel_iter(A,x0,b,nmax,tol);

niter
ressave(end)

%%%% non-diagonally dominant example

A2 = [-2 1 5; 4 -8 1; 4 -1 1];

U2 = triu(A2,1);
L2 = tril(A2);

norm(L2\U2)

b2 = [15; -21; 7];

x02 = [1; 2; 2];

nmax = 30;

tol = 1.0e-9;

[x2,niter2,xsave2,ressave2] = gauss_seidel_iter(A2,x02,b2,nmax,tol);

niter2
ressave2(end)