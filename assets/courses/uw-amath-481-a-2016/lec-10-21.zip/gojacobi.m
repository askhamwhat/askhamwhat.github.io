
%%%% diagonally dominant example

A = [4 -1 1; 4 -8 1; -2 1 5];

d = diag(A);

D = diag(d);

R = A-D;

norm(D\R)

b = [7; -21; 15];

x0 = [1; 2; 2];

nmax = 30;

tol = 1.0e-9;

[x,niter,xsave,ressave] = jacobi_iter(A,x0,b,nmax,tol);

niter
ressave(end)

%%%% non-diagonally dominant example

A2 = [-2 1 5; 4 -8 1; 4 -1 1];

d2 = diag(A2);

D2 = diag(d2);

R2 = A2-D2;

norm(D2\R2)

b2 = [15; -21; 7];

x02 = [1; 2; 2];

nmax = 30;

tol = 1.0e-9;

[x2,niter2,xsave2,ressave2] = jacobi_iter(A2,x02,b2,nmax,tol);

niter2
ressave2(end)