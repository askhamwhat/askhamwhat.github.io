Editing the file structure.tex is not
recommended. 

To add your name to the top right of
each page, change the line

\renewcommand{\myname}{}

in the main source file (hw*.tex) to

\renewcommand{\myname}{Your Full Name}
